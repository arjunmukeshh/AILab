from binarytree import build

def successors(node):
  return 2 * node, 2 * node + 1

def evaluate(node):
  return node


def minimax(node, player, level, limit):
  if level == limit:
    ans = evaluate(node)
    values[node - 1] = str([node, ans])
    return ans
    
  if player == 'max':
    ans = 0
    for nextNode in successors(node):
      ans = max(ans, minimax(nextNode, 'min', level + 1, limit))

    values[node - 1] = str([node, ans])
    return ans
  else:
    ans = 10000 #infinity
    for nextNode in successors(node):
      ans = min(ans, minimax(nextNode, 'max', level + 1, limit))

    values[node - 1] = str([node, ans])
    return ans
    
limit = int(input('Limit : '))
values = [None] * (2 ** (limit + 1) + 2)
print('Answer : ', minimax(1, 'max', 0, limit))
print(build(values))